import java.util.*;

class Account{
	final String bank_name="SBI";
	String branch_name, address;
	String userName, password;
	
	long account_no,account_balance;
	Account(String a, long b, long c, String d){
		branch_name=a;
		account_no=b;
		account_balance=c;
		address=d;
	}
	
	void setUserName_and_Password(String a, String b)
	{
		this.userName=a;
		this.password=b;
	}
	
	void credit(long a){
		account_balance+=a;
		System.out.println("Your Account with XXXX..9837 has been creditd with INR" + a);
	}
	
	void debit(long a){
		if(account_balance<a){
			System.out.println("Insufficient Balance!");
			return;
		}
		account_balance-=a;
		System.out.println("Your Account with xxxx..9837 has been debited with amount  " + a + ".  The available balance is " + account_balance);
	}
	
	void getBalance(){
		System.out.println("Account Balance is " + account_balance);
	}
	
	void exit(){
		System.out.print("              Do You want to EXIT/CANCEL?");
		Scanner input=new Scanner(System.in);
		String x=input.next();
		if(x=="exit") System.out.println("Exited");
	}
}

class Bank_Management{
	public static void main(String[] a){
		Account nithin=new Account("Basar", 82749873, 8748799, "HNO: 5-4-831");
		nithin.credit(20000);
		nithin.getBalance();
		nithin.debit(100000);
		nithin.exit();
	}
}
