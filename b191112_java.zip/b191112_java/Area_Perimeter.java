import java.util.*;
import java.lang.*;

class Shape{
	Shape(){
		System.out.println("Hello");
	}
	
	void getArea(){
		System.out.println("Calculates Area");
	}
	
	void getPerimeter(){
		System.out.println("Calculates Perimeter");
	}
}

class Rectangle extends Shape{
	int length, breadth;
	Rectangle(int l, int b){
		length=l;
		breadth=b;
	}
	
	void getArea(){
		super.getArea();
		System.out.println("Area of Rectangle: " + length*breadth);
	}
	
	void getPerimeter(){
		super.getPerimeter();
		System.out.println("Perimeter of Rectangle: " + 2*(length+breadth));
	}
}

class Square extends Shape{
	int side;
	Square(int l){
		side=l;
	}
	
	void getArea(){
		super.getArea();
		System.out.println("Area of Square: " + side*side);
	}
	
	void getPerimeter(){
		super.getPerimeter();
		System.out.println("Perimeter of Square: " + 4*side);
	}
}


class Area_Perimeter{
	public static void main(String[] a){
		Rectangle rect=new Rectangle(2,3);
		rect.getArea();
		rect.getPerimeter();
		Square sq=new Square(5);
		sq.getPerimeter();
		sq.getArea();
	}
}
