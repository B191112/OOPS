import java.util.*;
import java.lang.*;




class MatrixOp{

	pubic static void printMatrix(int[][] c, int r, int c){
		for(int i=0;i<r,i++){
			for(int j=0;j<c;j++) System.out.print(c[i][j]+" ");
			System.out.println("");
		}
	}

	public void Add(int[][] a, int[][] b, int r1, int c1, int r2, int c2){
		int[r1][c1] c;
		for(int i=0;i<r1;i++){
			for(int j=0;j<c1;j++) c[i][j]=a[i][j]+b[i][j];
		}
		printMatrix(c,r1,c1);
	}
	
	
	public void Multiply(int[][] a, int[][] b, int r1, int c1, int r2, int c2){
		if(r2!=c1) System.out.println("Multiplication Not Possible!");
			
		
	}
		





class Matrix{
	public static void main(String[] args){
		int r1,c1,r2,c3; 
		Scanner input=new Scanner(System.in);
		r1=input.nextInt();
		c1=input.nextInt();
		int[][] a=new int[r2][c2];
		int[][] b=new int[r2][c2]
		for(int i=0;i<r;i++){
			for(int j=0;j<c;j++) a[i][j]=input.nextInt();
		}
		for(int i=0;i<r;i++){
			for(int j=0;j<c;j++) b[i][j]=input.nextInt();
		}
		//Multiply(a,b,r1,c1,r2,c2);
	}
}
