import java.util.*;

class Perfect{
	public static void main(String args[]){
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
		int i=1;
		int sum=0;
		while(i<n){
			if(n%i==0) sum+=i;
			i++;
		}
		System.out.println(sum==n);
	}
}
