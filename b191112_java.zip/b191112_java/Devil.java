import java.util.*;

class Monster{
	String name;
	Monster(String a){
		name=a;
	}
	void attack(){
		System.out.println("Attack!");
	}
}

class FireMonster extends Monster{
	FireMonster(String a){
		super(a);
	}
	void attack(){
		System.out.println("FireMOnster Attacked");
	}
}

class WaterMonster extends Monster{
	WaterMonster(String a){
		super(a);
	}
	void attack(){
		System.out.println("WaterMonster Attacked");
	}
}

class StoneMonster extends Monster{
	StoneMonster(String a){
		super(a);
	}
	void attack(){
		System.out.println("StoneMonster Attacked");
	}
}

class Devil{
	public static void main(String[] a){
		FireMonster x=new FireMonster("NITHIN");
	        System.out.print(x.name);
	        x.attack();
	        Monster y=x;
	        y.attack();
	        Monster z=new Monster("swapnith");
	        z.attack();
	}
}
