import java.util.*;
import java.lang.*;

interface StudentFee{
	void getAdress();
	void getContact();
	void getAmount();
	void getFirstName();
	void getLastName();
}

class Hostler implements StudentFee{
	String first_name, last_name, contact, adress;
	int clg_fee, hstl_fee;
	Hostler(String a, String b, String c, String d, int e, int f){
		first_name=a; last_name=b; contact=c; adress=d; clg_fee=e;
		hstl_fee=f;
	}
	public void getFirstName(){
		System.out.println("First name is: " + first_name);
	}
	public void getLastName(){
		System.out.println("Last name is: " + last_name);
	}
	public void getAdress(){
		System.out.println("Adress is: " + adress);
	}
	public void getContact(){
		System.out.println("Contact number is: " + contact);
	}
	public void getAmount(){
		System.out.println("Amount to be paid is: " + (clg_fee+hstl_fee));
	}
}

class NonHostler implements StudentFee{
	String first_name, last_name, contact, adress;
	int clg_fee;
	NonHostler(String a, String b, String c, String d, int e){
		first_name=a; last_name=b; contact=c; adress=d; clg_fee=e;
	}
	public void getFirstName(){
		System.out.println("First name is: " + first_name);
	}
	public void getLastName(){
		System.out.println("Last name is: " + last_name);
	}
	public void getAdress(){
		System.out.println("Adress is: " + adress);
	}
	public void getContact(){
		System.out.println("Contact number is: " + contact);
	}
	public void getAmount(){
		System.out.println("Amount to be paid is: " + clg_fee);
	}
}

class HostelandNonHostel{
	public static void main(String args[]){
		StudentFee nithin=new Hostler("Nithin", "Ambati", "8688806058", "Hno: 5-4-831, BhulasxmiNagar, Hyd", 40000, 40000);
		
		System.out.println("\n");
		nithin.getFirstName();
		nithin.getLastName();
		nithin.getAdress();
		nithin.getContact();
		nithin.getAmount();
		
		System.out.println("\n");
		
		StudentFee vamshi=new NonHostler("Nithin", "Ambati", "8688806058", "Hno: 5-4-831, BhulasxmiNagar, Hyd", 40000);
		
		vamshi.getFirstName();
		vamshi.getLastName();
		vamshi.getAdress();
		vamshi.getContact();
		vamshi.getAmount();
		System.out.println("\n");
	}
}
