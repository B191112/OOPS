import java.util.*;
import java.lang.*;

abstract class Shape{
	abstract double getArea();
	abstract double getVolume();
}

class Square extends Shape{
	double side;
	Square(double s){
		side=s;
	}
	double getArea(){
		return side*side;
	}
	double getVolume(){
		return 0;
	}
}

class Circle extends Shape{
	double radius;
	Circle(double s){
		radius=s;
	}
	double getArea(){
		return 3.14*radius*radius;
	}
	double getVolume(){
		return 0;
	}
}

class Cube extends Shape{
	double side;
	Cube(double s){
		side=s;
	}
	double getVolume(){
		return side*side*side;
	}
	double getArea(){
		return side*side;
	}
}

class Sphere extends Shape{
	double radius;
	Sphere(double s){
		radius=s;
	}
	double getVolume(){
		return (4/3)*3.14*radius*radius*radius;
	}
	double getArea(){
		return 4*3.14*radius*radius;
	}
}

class Shape2Dand3D{
	public static void main(String[] arg){
		Square a=new Square(4);
		Circle b=new Circle(4);
		Cube c=new Cube(4);
		Sphere d=new Sphere(4);
		System.out.println("Area of Square: "+ a.getArea());
		System.out.println("Volume of Square: "+ a.getVolume());
		
		System.out.println("Area of Circle: "+ b.getArea());
		System.out.println("Volume of Square: "+ b.getVolume());
		
		System.out.println("Area of Cube: "+ c.getArea());
		System.out.println("Volume of Cube: "+ c.getVolume());
		
		System.out.println("Area of Sphere: "+ d.getArea());
		System.out.println("Volume of Sphere: "+ d.getVolume());
	}
}

