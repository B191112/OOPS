import java.util.*;
import java.lang.*;


abstract class Emp{
	 String name;
	 int salary;
	Emp(String s, int b){
		name=s; salary=b;
	}
	abstract void getAmount();
}

class WeeklyEmp extends Emp{
	int weeks;
	
	WeeklyEmp(String a, int k, int s) {
		super(a,k); weeks=s;
	}
	
	void getAmount(){
		System.out.println("Salary of " + name + " is : "+ weeks*salary);
	}
	
}

class HourlyEmp extends Emp{
	int hours;
	
	HourlyEmp(String a, int k, int s) {
		super(a,k); hours=s;
	}
	
	void getAmount(){
		System.out.println("Salary of " + name + " is : "+ hours*salary);
	}
	
}



class Employee{
	public static void main(String[] args){
		WeeklyEmp nithin=new WeeklyEmp("Nithin", 5000, 3);
		nithin.getAmount();
		HourlyEmp mahesh=new HourlyEmp("Mahesh", 100, 90);
		mahesh.getAmount(); 
	}
}
