import java.util.*;
import java.lang.*;

interface Vehicle{
	void getColor();
	void getNumber();
	void getConsumption();
}

class TwoWheeler implements Vehicle{
	String name;
	String Number;
	String color;
	int fuel;
	TwoWheeler(String a, String b, String c, int f){
		name=a; Number=b; color=c; fuel=f;
	}
	public void getColor(){
		System.out.println("Color of the Vechile is :" + color);
	}
	public void getNumber(){
		System.out.println("Number of the Vechile is :" + Number);
	}
	public void getConsumption(){
		System.out.println("Fuel consumed in the Vechile is :" + fuel + "Ltrs");
	}
}

class Vehicles{
	public static void main(String[] arg){
		Vehicle v1=new TwoWheeler("Bike", "TS 05-83-3283", "Blue", 2);
		v1.getColor();
		v1.getNumber();
		v1.getConsumption();
	}
}
