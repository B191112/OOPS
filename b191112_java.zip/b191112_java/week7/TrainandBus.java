import java.util.*;
import java.lang.*;

interface Fare{
	int getAmount();
}

class Train implements Fare{
	int amountPaid;
	Train(int a){
		amountPaid=a;
	}
	public int getAmount(){
		return amountPaid;
	}
}

class Bus implements Fare{
	int amountPaid;
	Bus(int a){
		amountPaid=a;
	}
	public int getAmount(){
		return amountPaid;
	}
}

class TrainandBus{
	public static void main(String[] arg){
		Fare a=new Train(70);
		System.out.println(a.getAmount());
		Fare b=new Bus(120);
		System.out.println(b.getAmount());
	}
}
