import java.util.*;
import java.lang.*;

class Quadratic{

	public static void main(String args[]){
		int a=1,b=20,c=5;
		double disc=(b*b)-(4*a*c);
		if(disc<0) System.out.println("Imaginary Roots");
		else if(disc==0){
			 System.out.println("Real and Equal roots");
			 double sqdisc=Math.sqrt(disc);
			 double root1=((-1*b)+sqdisc)/(2*a);
			double root2=((-1*b)-sqdisc)/(2*a);
			System.out.println(root1);
			System.out.println(root2);
		}
		else {
			System.out.println("Real Roots");
			double sqdisc=Math.sqrt(disc);
			 double root1=((-1*b)+sqdisc)/(2*a);
			double root2=((-1*b)-sqdisc)/(2*a);
			System.out.println(root1);
			System.out.println(root2);
		}
	}
}
