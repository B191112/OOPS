import java.util.*;
import java.lang.*;

class Min_max{
	public static void main(String args[]){
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
		int min=999999;
		int max=-999999;
		for(int i=0;i<n;i++){
			int a=input.nextInt();
			if(a>max) max=a;
			if(a<min) min=a;
		}
		System.out.println(max);
		System.out.println(min);
		
	}
}
