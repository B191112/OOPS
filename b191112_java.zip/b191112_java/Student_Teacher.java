import java.util.*;

class Person{
	String name, address;
	Person(String a, String b){
		name=a; address=b;
	}
	void getName(){
		System.out.println(name);
	}
	void getAddress(){
		System.out.println(address);
	}
	void setAddress(String a){
		this.address=a;
	}
}

class Student extends Person{
	int numCourses;
	String[] courses=new String[numCourses];
	int[] grades=new int[numCourses];
	
	Student(String a, String b, int n, String[] x, int[] y){
		super(a,b); numCourses=n; courses=x; grades=y;
	}
	void addCourse(String a, int g){
		if(numCourses==30) {
			System.out.println("LIMIT EXCEEDED");
			return;
		}
		courses[numCourses]=a;
		grades[numCourses]=g;
		numCourses++;
	}
	void printGrades(){
		for(int i: grades) System.out.print(i+" ");
		System.out.println("");
	}
	void printCourses(){
		for(String i: courses) System.out.print(i+" ");
		System.out.println("");
	}
	void getAvgGrade(){
		float sum=0;
		for(int i: grades) sum+=i;
		System.out.println(sum/numCourses);
	}
}


class Teacher extends Person{
	int numCourses;
	String[] courses=new String[numCourses];
	
	Teacher(String a, String b, int n, String[] x){
		super(a,b); numCourses=n; courses=x;
	}
	void printCourses(){
		for(String i: courses) System.out.print(i+" ");
		System.out.println("");
	}
	void addCourse(String a){
		if(numCourses==5) {
			System.out.println("LIMIT EXCEEDED");
			return;
		}
		courses[numCourses++]=a;
	}
	void removeCourse(String a){
		int i=0;
		for(i=0;i<numCourses;i++){
			if(courses[i]==a) break;
		}
		while(i<numCourses-1) {courses[i]=courses[i+1]; i++;}
		numCourses--;
	}
}

class Student_Teacher{
	public static void main(String[] a){
		int[] grades=new int[5];
		String[] courses=new String[30];
		courses[0]="OOPS"; grades[0]=10;
		courses[1]="OS"; grades[1]=10;
		courses[2]="BCT"; grades[2]=10;
		
		/*Student nithin=new Student("Nithin", "HNO: 5-4-831", 3, courses, grades);
		System.out.println(nithin.name);
		nithin.printGrades();
		nithin.printCourses();
		nithin.addCourse("lab", 10);
		nithin.printGrades();
		nithin.printCourses();*/
		
		Teacher mam=new Teacher("mam", "8743", 3, courses);
		System.out.println(mam.name);
		mam.printCourses();
		mam.addCourse("lab");
		mam.printCourses();
		mam.removeCourse("OS");
		mam.printCourses();
		
	}
}
