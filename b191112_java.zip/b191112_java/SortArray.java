import java.util.*;
import java.lang.*;

class SortArray{

	void merge(int[] arr, int l, int mid, int h){
		int i=l,j=mid+1;
		int[] brr=new int[n];
		int k=0;
		while(i<=mid && j<=h){
			if(arr[i]<=arr[j]) brr[k++]=arr[i++];
			else brr[k++]=arr[j++];
		}
		while(i<=mid) brr[k++]=arr[i++];
		while(j<=h) brr[k++]=arr[j++];
		for(i=0;i<k;i++) arr[l+i]=brr[i];
	}

	void mergeSort(int[] arr, int l, int h){
		if(l<h){
			int mid=(l+h)/2;
			mergeSort(arr,l,mid);
			mergeSort(arr,mid+1,h);
			merge(arr,l,mid,h);
		}
	}
	
	
	
	
	public static void main(String args[]){
		int n;
		Scanner input=new Scanner(System.in);
		n=input.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++) arr[i]=input.nextInt();
		mergeSort(arr,0,n-1);
		for(int i: arr) System.out.println(i);
	}
}
