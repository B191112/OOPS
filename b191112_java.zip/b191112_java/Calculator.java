import java.util.*;

class Calculator{
	public static void main(String args[]){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		String str=input.next();
		char operand=str.charAt(0);
		switch(operand){
			case '+':
				System.out.println(a+b);
				break;
			case '-':
				System.out.println(a-b);
				break;
			case '*':
				System.out.println(a*b);
				break;
			case '/':
				System.out.println(a/b);
				break;
		}
		
	}
}
