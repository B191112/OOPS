import java.util.*;
import java.lang.*;

class Palindrome2{
	public static void main(String args[]){
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
		int sum=0;
		int a=n;
		while(n>0){
			int rem=n%10;
			sum*=10;
			sum+=rem;
			n/=10;
		}
		System.out.println(sum==a);
	}
}
