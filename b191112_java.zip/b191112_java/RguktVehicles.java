import java.util.*;

class Vehicle{
	String company, model, mileage, fuelCapacity, displacement;
	Vehicle(String a, String b, String c, String d, String e){
		company=a;
		model=b;
		mileage=c;
		fuelCapacity=d;
		displacement=e;
	}
	
}

class TwoWheeler extends Vehicle{
	String frontBrake, rearBrake, tyre_type, headLamp, userReviews;
	TwoWheeler(String a, String b, String c, String d, String e, String f, String g, String h, String i, String j){
		super(a,b,c,d,e);
		frontBrake=f;
		rearBrake=g;
		tyre_type=h;
		headLamp=i;
		userReviews=j;
	}
}

class FourWheeler extends Vehicle{
	String airConditioner, airBags, powerSteering, rainSensing, wiper;
	FourWheeler(String a, String b, String c, String d, String e, String f, String g, String h, String i, String j){
		super(a,b,c,d,e);
		airConditioner=f;
		airBags=g;
		powerSteering=h;
		rainSensing=i;
		wiper=j;
	}
}

class RguktVehicles{
	public static void main(String[] a){
		TwoWheeler twoWheelers[]= new TwoWheeler[4];
		twoWheelers[0]=new TwoWheeler("Honda", "Delux", "60", "1500L", "50", "YES", "YES", "mrf", "Light", "****"); 
		twoWheelers[1]=new TwoWheeler("Pulser", "RS 200", "40", "1200L", "50", "YES", "YES", "mrf", "Light", "*****"); 
		
		
		FourWheeler fourWheelers[]= new FourWheeler[4];
		fourWheelers[0]=new FourWheeler("BMW", "BMW", "15", "2000L", "20", "YES", "YES", "YES", "YES", "YES"); 
		fourWheelers[1]=new FourWheeler("Maruthi", "i 20", "40", "1900L", "50", "YES", "NO", "NO", "NO", "NO"); 
		//System.out.println(fourWheelers[0].wiper);
		
		fourWheelers.findbest(fourWheelers[0], fourWheelers[1]);
		
	}
}
