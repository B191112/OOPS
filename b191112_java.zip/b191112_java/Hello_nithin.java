import java.util.*;
class Hello_nithin{
	public static void main(String args[]){
		System.out.print("Hello Nitin!");
	}
}
