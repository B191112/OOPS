import java.util.*;
import java.lang.*;
class Circle{
	int radius;
	String color;
	
	Circle(int x){
		radius=x;
	}
	
	void fillColor(String col){
		color=col;
	}
	
	double getarea(){
		return 3.14*radius*radius;
	}
	
	public static void main(String args[]){
		Circle obj1=new Circle(5);
		System.out.println(obj1.getarea());
		obj1.fillColor("Blue");
		System.out.println(obj1.color);
	}
}
