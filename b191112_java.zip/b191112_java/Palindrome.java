import java.util.*;
import java.lang.*;

class Palindrome{
	public static void main(String args[]){
		Scanner input=new Scanner(System.in);
		String str=input.next();
		int n=str.length();
		boolean flag=true;
		for(int i=0;i<n;i++){
			if(str.charAt(i)!=str.charAt(n-i-1)) flag=false;
		}
		System.out.println(flag);
	}
}
