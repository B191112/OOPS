import java.util.*;


class Emp{
	int id;
	String name;
	String dept;
	Emp(int x,String a,String b){
		id=x; name=a; dept=b;
	}
}

class WeeklyEmp extends Emp{
	int weeks;
	int salary;
	
	WeeklyEmp(int x,String a,String b, int s, int k) {
		super(x,a,b); weeks=s; salary=k;
	}
	
	void getSalary(){
		System.out.println("Salary of " + name + " is : "+ weeks*salary);
	}
	
}


class HourlyEmp extends Emp{
	int hours;
	int salary;
	
	HourlyEmp(int x,String a,String b, int s, int k) {
		super(x,a,b); hours=s; salary=k;
	}
	
	
	void getSalary(){
		System.out.println("Salary of " + name + " is : "+ hours*salary);
	}
	
}



class Employee{
	public static void main(String[] args){
		WeeklyEmp nithin=new WeeklyEmp(12, "Nithin", "CSE", 2, 500);
		nithin.getSalary();
	}
}
